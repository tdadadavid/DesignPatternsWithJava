package com.codewithmosh.visitor;

public abstract class Segment {
    public abstract void applyFilter(AudioFilter filter);
}
