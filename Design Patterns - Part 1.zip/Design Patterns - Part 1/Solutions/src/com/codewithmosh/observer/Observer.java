package com.codewithmosh.observer;

public interface Observer {
    void priceChanged();
}
