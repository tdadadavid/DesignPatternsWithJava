package com.codewithmosh.command;

public interface Command {
    void execute();
}
