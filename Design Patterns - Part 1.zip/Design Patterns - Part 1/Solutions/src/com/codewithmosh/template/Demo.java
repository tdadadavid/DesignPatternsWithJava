package com.codewithmosh.template;

public class Demo {
    public static void show() {
        var window = new ChatWindow();
        window.close();
    }
}
