package com.codewithmosh;

import com.codewithmosh.mediator.SignUpDialogBox;
import com.codewithmosh.visitor.Demo;

public class Main {

    public static void main(String[] args) {

        Demo.show();
    }
}
