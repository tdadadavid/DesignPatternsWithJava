package com.codewithmosh.state;

public interface TravelMode {
    Object getEta();
    Object getDirection();
}
