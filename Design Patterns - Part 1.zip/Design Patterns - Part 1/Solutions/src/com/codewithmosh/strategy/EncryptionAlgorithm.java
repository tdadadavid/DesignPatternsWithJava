package com.codewithmosh.strategy;

public interface EncryptionAlgorithm {
    String encrypt(String text);
}
