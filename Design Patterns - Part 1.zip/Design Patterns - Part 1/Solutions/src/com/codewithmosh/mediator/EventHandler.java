package com.codewithmosh.mediator;

public interface EventHandler {
    void handle();
}
