package com.codewithmosh.state;

public enum ToolType {
  SELECTION,
  BRUSH,
  ERASER
}
