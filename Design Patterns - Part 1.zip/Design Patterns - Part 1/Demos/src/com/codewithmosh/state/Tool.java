package com.codewithmosh.state;

public interface Tool {
  void mouseDown();
  void mouseUp();
}
