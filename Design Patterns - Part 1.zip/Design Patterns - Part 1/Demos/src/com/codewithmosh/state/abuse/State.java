package com.codewithmosh.state.abuse;

public interface State {
  void click();
}
