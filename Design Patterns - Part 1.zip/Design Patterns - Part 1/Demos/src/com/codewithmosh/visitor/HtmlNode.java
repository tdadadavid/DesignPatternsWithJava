package com.codewithmosh.visitor;

public interface HtmlNode {
  void execute(Operation operation);
}
