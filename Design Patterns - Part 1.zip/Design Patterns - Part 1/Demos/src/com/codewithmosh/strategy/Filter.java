package com.codewithmosh.strategy;

public interface Filter {
  void apply(String fileName);
}
