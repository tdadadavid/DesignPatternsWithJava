package com.codewithmosh;

public interface TaxCalculator {
  float calculateTax();
}
