package com.codewithmosh;

public class TaxCalculator2019 implements TaxCalculator {
  @Override
  public float calculateTax() {
    return 1;
  }

  public float calculateInsurance() {
    return 0;
  }
}
