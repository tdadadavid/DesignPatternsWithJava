package com.codewithmosh.command.editor;

public interface Command {
  void execute();
}
