package com.codewithmosh.command.fx;

public interface Command {
  void execute();
}
