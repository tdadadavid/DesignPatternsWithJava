package com.codewithmosh.command;

public class CustomerService {
  public void addCustomer() {
    System.out.println("Add customer");
  }
}
