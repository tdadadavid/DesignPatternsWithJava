package com.codewithmosh;

public class CheckBox extends UIControl {
  @Override
  public void draw() {
    System.out.println("Drawing a checkbox");
  }
}
