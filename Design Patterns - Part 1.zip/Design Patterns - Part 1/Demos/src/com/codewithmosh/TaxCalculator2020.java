package com.codewithmosh;

public class TaxCalculator2020 implements TaxCalculator {
  @Override
  public float calculateTax() {
    return 2;
  }
}
