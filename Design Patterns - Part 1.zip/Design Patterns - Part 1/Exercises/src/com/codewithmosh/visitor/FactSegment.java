package com.codewithmosh.visitor;

public class FactSegment extends Segment {
}
