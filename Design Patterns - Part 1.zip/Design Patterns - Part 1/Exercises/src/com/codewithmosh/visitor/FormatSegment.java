package com.codewithmosh.visitor;

public class FormatSegment extends Segment {
}
