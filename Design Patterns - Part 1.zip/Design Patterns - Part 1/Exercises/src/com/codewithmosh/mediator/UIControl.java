package com.codewithmosh.mediator;

public class UIControl {
}
