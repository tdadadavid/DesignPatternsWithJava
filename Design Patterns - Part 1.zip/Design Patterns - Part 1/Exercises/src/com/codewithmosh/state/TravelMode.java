package com.codewithmosh.state;

public enum TravelMode {
    DRIVING,
    BICYCLING,
    TRANSIT,
    WALKING
}
